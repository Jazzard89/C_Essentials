﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
Console.WriteLine("please enter your name");
string name = Console.ReadLine();
Console.WriteLine("hello " + name);
Console.WriteLine("what's up bro");
string drone = Console.ReadLine();
Console.WriteLine(drone);