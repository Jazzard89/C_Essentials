﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.PerformanceData;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace BlackJack
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    //berekening maken en geef getallen mee Method(meegeven, meegeven;
    //private int (meegeven, meegeven) return uitkomst;
    public partial class MainWindow : Window
    {
        Random rnd = new Random();
        StringBuilder handBuilderPlayer = new StringBuilder();
        StringBuilder handBuilderBank = new StringBuilder();
        int scoreSpeler;
        int scoreBank;
        int hiddenCardValue;
        int cardpicked;
        string[] standardDeckArray = new string[]{
            "Diamonds 1", "Hearts 1", "Clover 1", "Spades 1",
            "Diamonds 2", "Hearts 2", "Clover 2", "Spades 2",
            "Diamonds 3", "Hearts 3", "Clover 3", "Spades 3",
            "Diamonds 4", "Hearts 4", "Clover 4", "Spades 4",
            "Diamonds 5", "Hearts 5", "Clover 5", "Spades 5",
            "Diamonds 6", "Hearts 6", "Clover 6", "Spades 6",
            "Diamonds 7", "Hearts 7", "Clover 7", "Spades 7",
            "Diamonds 8", "Hearts 8", "Clover 8", "Spades 8",
            "Diamonds 9", "Hearts 9", "Clover 9", "Spades 9",
            "Diamonds 10", "Hearts 10", "Clover 10", "Spades 10",
            "Diamonds Jack", "Hearts Jack", "Clover Jack", "Spades Jack",
            "Diamonds Queen", "Hearts Queen", "Clover Queen", "Spades Queen",
            "Diamonds King", "Hearts King", "Clover King", "Spades King",};
        int[] usedCardsArray = new int[100];
        int usedCardsArrayPosition = 1;
        int cardValue2;
        bool whoPlays;
        bool eersteKaart;
        string hiddenCard;
        int counter2;
        int kapitaal;
        int inzet;
        int counter;
        Image kaartLinks = new Image();
        Image kaartMidden = new Image();
        Image kaartRechts = new Image();
        int eersteKaartImage;
        int tweedeKaartImage;
        int derdeKaartImage;
        int overloadAceSpeler;
        int overloadAceBank;



        //nieuw spel = budget 100euro
        //spelers kunnen inzet geven, indien win dubbel, indien verlies kwijt
        //kapitaal = null, = nieuw spel
        //minimum inzet 10% omhoog afgerond
        //deel kaarten onderbrekeing 1 sec
        public MainWindow()
        {
            InitializeComponent();
        }
        private void DeckShuffle()
        {
            //kies random nummer uit deck
            cardpicked = rnd.Next(1, 52);
            //controle of random nummer al gekozen was indien wel, kies nieuw nummer
            for (int i = 52; i > -1; i--)
            {
                //usedCardsArray is array waar niets inzit in het begin
                if (cardpicked == usedCardsArray[i])
                {
                    cardpicked = rnd.Next(1, 53);
                    i = 52;
                }
            }
            //voeg random nummer toe aan array gekozenKaarten
            usedCardsArray[usedCardsArrayPosition] = cardpicked;
            /*
                        txtTest.Visibility = Visibility.Visible;
                        txtTest2.Visibility = Visibility.Visible;
                        //Controle orgaan op lijst die kaarten bevat
                        txtTest2.Items.Add(usedCardsArray[usedCardsArrayPosition]);
                        usedCardsArrayPosition++;
            */
            //waarde koppelen aan kaart
            switch (cardpicked)
            {
                //Aas
                case 1:
                case 2:
                case 3:
                case 4:
                    if ((whoPlays == true ) && (scoreBank <= 10))
                    {
                        cardValue2 = 11;
                        overloadAceBank = +10;
                    }

                    if ((whoPlays == false) && (scoreSpeler <= 10))
                    {
                        cardValue2 = 11;
                        overloadAceSpeler = +10;
                    }

                    else if (((scoreBank > 10) && (whoPlays == true)) || ((scoreSpeler > 10) && (whoPlays == false)))
                    {
                        cardValue2 = 1;
                    }


                    break;

                //Kaart 2
                case 5:
                case 6:
                case 7:
                case 8:
                    cardValue2 = 2;
                    break;

                //Kaart 3
                case 9:
                case 10:
                case 11:
                case 12:
                    cardValue2 = 3;
                    break;
                //Kaart 4
                case 13:
                case 14:
                case 15:
                case 16:
                    cardValue2 = 4;
                    break;

                //Kaart 5
                case 17:
                case 18:
                case 19:
                case 20:
                    cardValue2 = 5;
                    break;

                //Kaart 6
                case 21:
                case 22:
                case 23:
                case 24:
                    cardValue2 = 6;
                    break;

                //Kaart 7
                case 25:
                case 26:
                case 27:
                case 28:
                    cardValue2 = 7;
                    break;

                //Kaart 8
                case 29:
                case 30:
                case 31:
                case 32:
                    cardValue2 = 8;
                    break;

                //Kaart 9
                case 33:
                case 34:
                case 35:
                case 36:
                    cardValue2 = 9;
                    break;

                //Kaart 10
                case 37:
                case 38:
                case 39:
                case 40:

                //Kaart Boer
                case 41:
                case 42:
                case 43:
                case 44:

                //Kaart Dame
                case 45:
                case 46:
                case 47:
                case 48:

                //Kaart Koning
                case 49:
                case 50:
                case 51:
                case 52:
                    cardValue2 = 10;
                    break;
            }





            //schrijf string
            //beurt aan speler///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (whoPlays == false)
            {
                //bovenstaande toevoegen aan string
                handBuilderPlayer.AppendLine($"{standardDeckArray[cardpicked - 1]}");
                txtRstSpeler.Text = handBuilderPlayer.ToString();
                scoreSpeler = scoreSpeler + cardValue2;
                txtScoreSpeler.Text = Convert.ToString(scoreSpeler);
                //derde kaart
                if (counter > 1)
                {
                    //nieuwe kaart tonen
                    imgKaartRechts.Visibility = Visibility.Visible;
                    //kaarten var
                    kaartRechts.Source = new BitmapImage(new Uri($@"{eersteKaartImage - 1}.png", UriKind.Relative));
                    derdeKaartImage = cardpicked;
                    kaartMidden.Source = new BitmapImage(new Uri($@"{tweedeKaartImage - 1}.png", UriKind.Relative));
                    kaartLinks.Source = new BitmapImage(new Uri($@"{derdeKaartImage - 1}.png", UriKind.Relative));
                    //zet kaarten op source
                    imgKaartRechts.Source = kaartRechts.Source;
                    imgKaartMidden.Source = kaartMidden.Source;
                    imgKaartLinks.Source = kaartLinks.Source;
                    counter++;
                }
                //tweede kaart
                if (counter == 1)
                {
                    //nieuwe kaart tonen
                    imgKaartMidden.Visibility = Visibility.Visible;
                    //kaarten var
                    kaartMidden.Source = new BitmapImage(new Uri($@"{eersteKaartImage-1}.png", UriKind.Relative));
                    tweedeKaartImage = cardpicked;
                    kaartLinks.Source = new BitmapImage(new Uri($@"{tweedeKaartImage-1}.png", UriKind.Relative));
                    //zet kaarten op source
                    imgKaartMidden.Source = kaartMidden.Source;
                    imgKaartLinks.Source = kaartLinks.Source;
                    counter++;
                }
                //eerste kaart
                if (counter == 0)
                {
                    imgKaartLinks.Visibility = Visibility.Visible;
                    eersteKaartImage = cardpicked;
                    kaartLinks.Source = new BitmapImage(new Uri($@"{eersteKaartImage - 1}.png", UriKind.Relative));
                    imgKaartLinks.Source = kaartLinks.Source;
                    counter++;
                }
                whoPlays = true;
            }
            //beurt aan computer////////////////////////////////////
            else
            {
                //na eerste beurt bank
                if (eersteKaart == true)
                {
                    handBuilderBank.AppendLine($"{standardDeckArray[cardpicked - 1]}");
                    txtRstBank.Text = handBuilderBank.ToString();
                    scoreBank = scoreBank + cardValue2;
                    txtScoreBank.Text = Convert.ToString(scoreBank);
                    whoPlays = false;
                }

                //eerste beurt bank
                else if (eersteKaart == false)
                {
                    hiddenCard = Convert.ToString(standardDeckArray[cardpicked - 1]);
                    hiddenCardValue = cardValue2;
                    eersteKaart = true;
                    whoPlays = false;
                }
            }
        }
        private async void btnDeel_Click(object sender, RoutedEventArgs e)
        {
            imgKaartRechts.Visibility = Visibility.Hidden;
            imgKaartMidden.Visibility = Visibility.Hidden;
            imgKaartLinks.Visibility = Visibility.Hidden;
            counter = 0;
            overloadAceSpeler = 0;    
            try
            {
                inzet = Convert.ToInt32(txtInzet.Text);
                while (inzet > kapitaal)
                {
                    MessageBox.Show("Bedrag mag niet boven je kapitaal gaan");
                    txtInzet.Clear();
                    inzet = 0;
                }
                int minimumInzet = kapitaal / 10;
                while (inzet < minimumInzet)
                {
                    MessageBox.Show("Er is een minimum inzet van 10%");
                    txtInzet.Clear();
                    inzet = 0;
                    minimumInzet = 0;
                }
                if ((inzet <= kapitaal) && (inzet != 0))
                {
                    txtInzet.IsReadOnly = true;
                    kapitaal = kapitaal - inzet;
                    txtInzet.Text = Convert.ToString($"{inzet:c}");
                    txtKapitaal.Text = Convert.ToString($"{kapitaal:c}");



                    Cleaning2();
                    btnHit.IsEnabled = true;
                    btnStand.IsEnabled = true;
                    btnDeel.IsEnabled = false;
                    await Task.Delay(500);
                    DeckShuffle();
                    await Task.Delay(500);
                    DeckShuffle();
                    await Task.Delay(500);
                    DeckShuffle();
                    await Task.Delay(500);
                    DeckShuffle();
                    Winnaar();

                }




            }



            //catch dat er niets staat ingevuld
            catch (FormatException)
            {
                MessageBox.Show("Voer een bedrag in");
            }

           //catch dat er geen nummer staat
            catch (Exception)
            {
                MessageBox.Show("Input is niet correct");
            }








        }

        private void Cleaning()
        {
            btnDeel.IsEnabled = true;
            btnHit.IsEnabled = false;
            btnStand.IsEnabled = false;

            handBuilderPlayer.Clear();
            handBuilderBank.Clear();
            scoreBank = 0;
            scoreSpeler = 0;
            cardpicked = 0;
            counter2 = 0;
            hiddenCardValue = 0;
            cardValue2 = 0;
            whoPlays = false;
            eersteKaart = true;
            hiddenCard = null;
            usedCardsArrayPosition = 1;

            //toegevoegd
            txtInzet.Clear();
            txtInzet.IsReadOnly = false;

            for (int i = 52; i > -1; i--)
            {
                usedCardsArray[i] = 0;
            }
        }

        private void Cleaning2()
        {
            eersteKaart = false;
            handBuilderPlayer.Clear();
            handBuilderBank.Clear();
            scoreBank = 0;
            scoreSpeler = 0;
            cardpicked = 0;
            counter2 = 0;
            hiddenCardValue = 0;
            cardValue2 = 0;
            hiddenCard = null;
            usedCardsArrayPosition = 1;
            for (int i = 52; i > -1; i--)
            {
                usedCardsArray[i] = 0;
            }
        }

        private void Winnaar()
        {
            if (scoreBank > 21)
            {
                if (overloadAceBank >= 10)
                {
                    scoreBank = scoreBank - 10;
                }
                MessageBox.Show($"BUST! Speler wint!");
                inzet = inzet * 2;
                kapitaal = kapitaal + inzet;
                txtInzet.Text = Convert.ToString($"{inzet:c}");
                txtKapitaal.Text = Convert.ToString($"{kapitaal:c}");
                Cleaning();
            }
            /////////////////////////////////////////////////////////////////////////////hier testen
            if (scoreSpeler > 21)
            {
                if (overloadAceSpeler == 0)
                {
                    MessageBox.Show($"BUST! Bank wint!");
                    inzet = 0;
                    Cleaning();
                }

                if (overloadAceSpeler >= 10)
                {
                    scoreSpeler = scoreSpeler - 10;
                    txtScoreSpeler.Text = Convert.ToString(scoreSpeler);
                }







                if (kapitaal == 0)
                {
                    MessageBox.Show("Je bent blut!");
                    btnNieuw.IsEnabled = true;
                    btnDeel.IsEnabled = false;
                    txtInzet.IsEnabled = false;
                    txtKapitaal.IsEnabled = false;
                    Cleaning();
                }

                
            }





            if (scoreBank >= 17)
            {
                if ((scoreBank > 21) || (scoreSpeler > scoreBank))
                {
                    MessageBox.Show($"Speler wint!");
                    inzet = inzet * 2;
                    kapitaal = kapitaal + inzet;
                    txtInzet.Text = Convert.ToString($"{inzet:c}");
                    txtKapitaal.Text = Convert.ToString($"{kapitaal:c}");
                }

                if ((scoreSpeler > 21) || (scoreBank > scoreSpeler))
                {
                    MessageBox.Show($"Bank wint!");
                    inzet = 0;



                    if (kapitaal == 0)
                    {
                        MessageBox.Show("Je bent blut!");
                        btnNieuw.IsEnabled = true;
                        btnDeel.IsEnabled = false;
                        txtInzet.IsEnabled = false;
                        txtKapitaal.IsEnabled = false;
                    }
                }

                if ((scoreSpeler > 21) || (scoreBank == scoreSpeler))
                {
                    MessageBox.Show($"Gelijkspel!");
                }




                Cleaning();
            }


        }
        private async void btnHit_Click(object sender, RoutedEventArgs e)
        {
            btnStand.IsEnabled = true;
            btnDeel.IsEnabled = false;
            //whoplays veranderen zodat het de speler zijn beurt is
            whoPlays = false;
            await Task.Delay(500);
            DeckShuffle();
            Winnaar();
        }
        private async void btnStand_Click(object sender, RoutedEventArgs e)
        {
            //schrijf hier het verborgen getal
            if (counter2 == 0)
            {
                handBuilderBank.AppendLine($"{hiddenCard}");
                txtRstBank.Text = handBuilderBank.ToString();
                scoreBank = scoreBank + hiddenCardValue;
                txtScoreBank.Text = Convert.ToString(scoreBank);
                hiddenCardValue = 0;

                counter2 = 1;

                //while loop (not 17 draw a card)
                while (scoreBank < 17)
                {
                    whoPlays = true;
                    await Task.Delay(500);
                    DeckShuffle();

                }
                Winnaar();
                btnHit.IsEnabled = false;
            }





            if (counter2 == 1)
            {

                Winnaar();
                counter2 = 0;
            }
        }

        private void btnNieuw_Click(object sender, RoutedEventArgs e)
        {
            txtInzet.Focus();
            btnDeel.IsEnabled = true;
            kapitaal = 100;
            txtKapitaal.Text = Convert.ToString($"{kapitaal:c}");
            txtInzet.Clear();
            txtInzet.IsReadOnly = false;
            txtInzet.IsEnabled = true;
            txtKapitaal.IsEnabled = true;
            btnNieuw.IsEnabled = false;
            overloadAceSpeler = 0;
            overloadAceBank = 0;


            Cleaning2();


        }


    }
}
